================================================================================

OOP, Final project

by: Ahmad imam , id:206460651
    Nadeen Sob Laban , id:209310077
================================================================================

Description
===========
we built the game Tiny Toon Adventures with C++ using "SFML". 

instructions
============

joystick:

use "Left" and "Right" buttons to move left and right.
use "Space" button to jump.
use "x" to throw fire (carrots).


kill/ die:

1-in collision between player and enemy:
  if the player jumps the player kills the enemy, 
  otherwise the enemy kills the player.
2-in collision between fireCarrots and enemy :
  if player throw fireCarrots toward the enemy for the kill.

Complete level:

In order to complete a level the player needs to collect all the carrots that he has to collect it in the current level, 
the carrots number will be displayed in the status bar , he can collect more than he has to collect,  to use it like fire to kill the enemy.
if the player arrived the door and the number of the carrots is less than the required  the player cant complete  the level ,because of that we 
add a AddCarrots Gift in our game that the player can get 3 more carrots and to pay attention how many carrots to throw (and how many carrots he
has to collect to complete the level)

================================================================================
We used: Singleton(ResourceManager), States design, Factory, Multy Dispach

================================================================================
List of files
1) Menu.cpp – the purpose of this class is to have a menu in which the player can choose if he wants to play, get help, view the game controls or quit.
   it runs in the main function and turns on the game.
2) Controller.cpp - runs the game after the play option and player character is chosen, runs all controls, buttons and all the game objects, responsible for jumping, firing and to activate other game classes as well, and also it runs all nesting classes.
3) Board.cpp– the purpose of this class is to have a game board in which all objects will appear and interact with each other, it uses the collision class multi methods to activate collisions between objects.
4) Singelton.cpp  – it's purpose is to load the images and sound files.
5) Main.cpp - the main function, it defines an object of menu class and runs the run function from it.
6) Collision.cpp - the multi methods map class, stores all collision functions in a map and instanciates them only once when used like in singelton.
7) GameObject - the abstract base class to store gameobjects and their functions for polymorphism.
8) StaticObject - a derived class from the abstract base class "gameObject " to store the static game objects such as "Block, Path, Door, etc.." and their functions for polymorphism.
9) ActiveObject.cpp -  a derived class from the abstract base class "GameObject " to store the Active game objects such as "player, Mouse,Dog,Bird,FireCarrots" and their functions for polymorphism.
10) Player.cpp - a derived class from ActiveObject class, it defines the specific ActiveObject as Player and sets it's functions acordingly.
11) Enemy.cpp - a derived class from ActiveObject class, it defines the specific ActiveObject as Enemy and sets it's functions acordingly.
13) Bird.cpp - a derived class from Enemy class, it defines the specific Enemy as Bird and sets it's functions acordingly.
14) Mouse.cpp - a derived class from Enemy class, it defines the specific Enemy as Mouse and sets it's functions acordingly.
15) FireCarrots.cpp - it defines the specific Fire carrots and sets it's functions acordingly.
16) Caroots.cpp - it defines the specific Carrots and it's functions acordingly.
17) Floor.cpp - a derived class from StaticObject class, it defines the specific StaticObject as Floor and it's functions acordingly.
18) Door.cpp - a derived class from StaticObject class, it defines the specific StaticObject as Door and it's functions acordingly.
19) SpecialBlock.cpp - a derived class from StaticObject class, it defines the specific StaticObject as SpecialBlock and it's functions acordingly.
20) Block.cpp - a derived class from StaticObject class, it defines the specific StaticObject as Block and it's functions acordingly.
21) StatusBar.cpp - the object that sets all sats of the level.
22) AddLifeGift.cpp - a derived class from Gift class, it defines the specific Gift as AddLifeGift and it's functions acordingly.
23) AddScoreGift.cpp - a derived class from Gift class, it defines the specific Gift as AddScoreGift and it's functions acordingly.
24) AddCarrotsGift.cpp - a derived class from Gift class, it defines the specific Gift as AddCarrotsGift and it's functions acordingly.


and 5 level files (from 1-5).
=============================
Levels Format
============================
The format is "level"+ "number of stage"+ ".txt"

================================================================================

Data structures:
1) Controller: stores the player object and the vectors of FireeCarrots instances, also it includes the SFML library into the game in addition it stores the game clock and the object of the game board.
2) Singelton: stores all the All image files and sound files In vectors, to draw on the game board.
3) Board: holds a matrix of the loaded file and the vectors of unique pointers to all the Enemies in the level and all the level obsticles.
4) Collision: stores the map of collision functions to use in the board class for interaction between defferent objects.
5) StatusBar: holds the player status of the lives, Carrots, player score, player lives.
================================================================================
Worth to mention algorithms: 
Manhattan Algorithm for Smart Enemy AI, used  Bird objects.
================================================================================
