#pragma once

#include "StatusBar.h"
#include <iostream>

StatusBar::StatusBar(int l, int s, int c)
	: m_lives(l), m_score(s), m_Carrots(c), m_time_bonus(0), m_minutes(0)
{
	m_font.loadFromFile("font_statusBar.ttf");
	lives.setCharacterSize(60);
	score.setCharacterSize(60);
	Carrots.setCharacterSize(55);
	lives.setScale(0.2, 10.5);
	score.setScale(0.2, 10.5);
	Carrots.setScale(0.2, 10.5);
	lives.setPosition(40, 40);
	score.setPosition(125, 25);
	Carrots.setPosition(213, 30);
	lives.setFillColor(sf::Color::White);
	score.setFillColor(sf::Color::White);
	Carrots.setFillColor(sf::Color::White);
	lives.setFont(m_font);
	score.setFont(m_font);
	Carrots.setFont(m_font);
}

const int StatusBar::get_lives()  const
{
	return m_lives;
}

const int StatusBar::get_score() const
{
	return m_score;
}

int StatusBar::get_Carrots()  
{
	return m_Carrots;
}
const int StatusBar::get_Carrots_goal() const
{
	return m_CarrotsGoal;
}

void StatusBar::set_goals( int& Carrots)
{
	m_CarrotsGoal = Carrots;
}

void StatusBar::set_lives(int lives)
{
	m_lives += lives;
}

void StatusBar::set_score(int score) 
{
	m_score += score;
}



void StatusBar::set_Carrots(int diamond) 
{
	m_Carrots += diamond;
}

//set game clock
void StatusBar::setGameClock(int elapsedTime, sf::RenderWindow& window)
{
	m_minutes = (elapsedTime / 60) + m_time_bonus;

	if ((elapsedTime % 60) < 10 && (m_minutes) < 10)
		m_clockNum.setString("0" + std::to_string(m_minutes) + ":0" + std::to_string(elapsedTime % 60));
	else if ((elapsedTime % 60) >= 10 && (m_minutes) >= 10)
		m_clockNum.setString(std::to_string(m_minutes) + ":" + std::to_string(elapsedTime % 60));
	if ((elapsedTime % 60) >= 10 && (m_minutes) < 10)
		m_clockNum.setString("0" + std::to_string(m_minutes) + ":" + std::to_string(elapsedTime % 60));
	else
		m_clockNum.setString("0" + std::to_string(m_minutes) + ":0" + std::to_string(elapsedTime % 60));

	m_clockNum.setFont(m_font);
	m_clockNum.setStyle(sf::Text::Regular);
	m_clockNum.setCharacterSize(60);
	m_clockNum.setScale(0.2, 10.5);
	m_clockNum.setPosition(303, 70);
	
	if (elapsedTime < 10)
	{
		if(elapsedTime % 2 == 0)
			m_clockNum.setFillColor(sf::Color::Red);
		else
			m_clockNum.setFillColor(sf::Color::White);
	}
	else
		m_clockNum.setFillColor(sf::Color::White);

	window.draw(m_clockNum);
}

void StatusBar::resetResources() 
{
	m_Carrots = 0;
}

void StatusBar::draw(sf::RenderWindow& window)
{
	s_lives.str("");
	s_score.str("");
	s_Carrots.str("");
	s_lives << "Lives: " << get_lives();
	lives.setString(s_lives.str());
	s_score << "Score: " << get_score();
	score.setString(s_score.str());
	s_Carrots << "Carrots: " << get_Carrots() << "/" << m_CarrotsGoal;
	Carrots.setString(s_Carrots.str());
	window.draw(lives);
	window.draw(score);
	window.draw(Carrots);
}

StatusBar::~StatusBar()
{
}
