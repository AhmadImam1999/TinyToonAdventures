#include "Collision.h"


//constructor
Collision::Collision()
{
	m_ObjectsMap = initializeCollisionMap();
}

//Map build
HitMap Collision::initializeCollisionMap()
{
	HitMap phm; 
	phm[typesPair(typeid(Player), typeid(BabsBunny))] = &playerBabsBunny;
	phm[typesPair(typeid(Mouse),    typeid(FireCarrots))] = &MouseFireCarrots;
	phm[typesPair(typeid(FireCarrots),    typeid(Mouse))] = &FireCarrotsMouse;
	phm[typesPair(typeid(Player),     typeid(Door))] = &playerDoor;
	phm[typesPair(typeid(Player),     typeid(Carrots))] = &playerCarrots;
	phm[typesPair(typeid(Mouse),      typeid(Carrots))] = &EnemyItem;
	phm[typesPair(typeid(Mouse), typeid(AddLifeGift))] = &EnemyItem;
	phm[typesPair(typeid(Mouse), typeid(AddCarrotsGift))] = &EnemyItem;
	phm[typesPair(typeid(Mouse), typeid(AddScoreGift))] = &EnemyItem;
	///<summary>
	
	phm[typesPair(typeid(Dog), typeid(Carrots))] = &EnemyItem;
	phm[typesPair(typeid(Dog), typeid(AddLifeGift))] = &EnemyItem;
	phm[typesPair(typeid(Dog), typeid(AddCarrotsGift))] = &EnemyItem;
	phm[typesPair(typeid(Dog), typeid(AddScoreGift))] = &EnemyItem;
	/// <returns></returns>
	phm[typesPair(typeid(Bird), typeid(AddLifeGift))] = &EnemyItem;
	phm[typesPair(typeid(Bird), typeid(AddCarrotsGift))] = &EnemyItem;
	phm[typesPair(typeid(Bird), typeid(AddScoreGift))] = &EnemyItem;
	phm[typesPair(typeid(Mouse), typeid(Rope))] = &EnemyItem;
	phm[typesPair(typeid(Dog), typeid(Rope))] = &EnemyItem;
	phm[typesPair(typeid(Bird), typeid(Rope))] = &EnemyItem;
	phm[typesPair(typeid(Mouse),      typeid(Door))] = &EnemyItem;
	phm[typesPair(typeid(Mouse),      typeid(Door))] = &EnemyItem;
	phm[typesPair(typeid(Dog), typeid(Door))] = &EnemyItem;
	phm[typesPair(typeid(Dog), typeid(Door))] = &EnemyItem;
	phm[typesPair(typeid(Bird),       typeid(Carrots))] = &EnemyItem;
	phm[typesPair(typeid(Bird),       typeid(Door))] = &EnemyItem;
	phm[typesPair(typeid(Bird),        typeid(Player))] = &BirdPlayer;
	phm[typesPair(typeid(Mouse),       typeid(Player))] = &MousePlayer;	
	phm[typesPair(typeid(Dog), typeid(Player))] = &DogPlayer;
	phm[typesPair(typeid(Player),       typeid(Mouse))] = &playerMouse;
	phm[typesPair(typeid(Player), typeid(Dog))] = &playerDog;
	phm[typesPair(typeid(Bird),            typeid(Block))] = &BirdBlock;
	phm[typesPair(typeid(Mouse),           typeid(Block))] = &MouseBlock;
	phm[typesPair(typeid(Dog), typeid(Block))] = &DogBlock;
	phm[typesPair(typeid(Bird),     typeid(BabsBunny))] = &BirdBabsBunny;
	phm[typesPair(typeid(Mouse),    typeid(BabsBunny))] = &MouseBlock;
	phm[typesPair(typeid(Dog), typeid(BabsBunny))] = &DogBlock;
	phm[typesPair(typeid(Player),         typeid(Bird))] = &playerBird;
	phm[typesPair(typeid(Player),         typeid(Block))] = &PlayerBlock;
	phm[typesPair(typeid(Bird),          typeid(Floor))] = &BirdPath;
	phm[typesPair(typeid(Mouse),         typeid(Floor))] = &MousePath;
	phm[typesPair(typeid(Dog), typeid(Floor))] = &DogPath;
	phm[typesPair(typeid(Player),        typeid(Floor))] = &playerPath;
	phm[typesPair(typeid(Player), typeid(Rope))] = &playerRope;
	phm[typesPair(typeid(Player), typeid(AddScoreGift))] = &playerAddScoreGift;
	phm[typesPair(typeid(Player), typeid(AddLifeGift))] = &playerAddLifeGift;
	phm[typesPair(typeid(Player), typeid(AddCarrotsGift))] = &playerAddCarrotsGift;
	return phm;
}

//searches the map for pairs
HitFunctionPtr Collision::lookup(const std::type_index& class1, const std::type_index& class2) 
{
	auto mapEntry = m_ObjectsMap.find(std::make_pair(class1, class2));
	if (mapEntry == m_ObjectsMap.end())
	{
		return nullptr;
	}
	return mapEntry->second;
}

//uses the lookup function
void Collision::processCollision(GameObject& object1, GameObject& object2) 
{
	auto phf = lookup(typeid(object1), typeid(object2));
	if (!phf)
	{
		std::cout << typeid(object1).name() << " " << typeid(object2).name();
		throw std::runtime_error("Collide error");	
	}
	phf(object1, object2);
}

//uses static return
Collision& Collision::instance() 
{
	static Collision instance;
	return instance;
}

void playerCarrots(GameObject& player, GameObject& Carrots) 
{
	Singleton::show().get_sound(2).play();
	Player& p = static_cast<Player&>(player);
	p.addCarrots();
	p.increaseScore();
}
void playerRope(GameObject& player, GameObject& Carrots)
{

	Player& p = static_cast<Player&>(player);
	bool status = p.getClimbStatus();
	if (!status)
		p.setClimb(true);
}

void playerDoor(GameObject& player, GameObject& Door) 
{
	
	Player& p = static_cast<Player&>(player);

	if (p.getCarrots() >= p.getCarrotsGoal())
		p.setDoorPassStatus(true);
	
}



void playerBabsBunny(GameObject& player, GameObject& SpecialBlock) 
{
	Player& p = static_cast<Player&>(player);
	if (p.getCarrots() >= p.getCarrotsGoal())
		p.setDoorPassStatus(true);
		
	
}


void playerBlock(GameObject& player, GameObject& Block) 
{
	Player& p = static_cast<Player&>(player);
	
		p.fix_position();
		p.setJump(false);
	
}



void playerMouse(GameObject& player, GameObject& Enemy) 
{

	Player& p = static_cast<Player&>(player);
	p.decreaseLife();
	p.resetPosition();
	p.setJump(false);
}
void playerDog(GameObject& player, GameObject& Enemy)
{

	Player& p = static_cast<Player&>(player);
	p.decreaseLife();
	p.resetPosition();
	p.setJump(false);
}

void MousePlayer(GameObject& Enemy, GameObject& player) 
{
	playerMouse(player, Enemy);
}
void DogPlayer(GameObject& Enemy, GameObject& player)
{
	playerMouse(player, Enemy);
}

void playerBird(GameObject& player, GameObject& Enemy) 
{
	playerMouse(player, Enemy);
}
void BirdPlayer(GameObject& Enemy, GameObject& player) 
{
	playerMouse(player, Enemy);
}

void EnemyItem(GameObject& monster, GameObject& player) 
{
}




void BirdBlock(GameObject& bird, GameObject& Block) 
{
	Bird& b = static_cast<Bird&>(bird);
	b.fix_position();
}

void BirdBabsBunny(GameObject& Bird, GameObject& SpecialBlock)
{
}

void BirdFireCarrots(GameObject& Bird, GameObject& FireCarrots)
{

}

void MouseBlock(GameObject& mouse, GameObject& Block) 
{
	Mouse& m = static_cast<Mouse&>(mouse);
	m.fix_position();
	m.set_direction();
}
void DogBlock(GameObject& dog, GameObject& Block)
{
	Dog& d = static_cast<Dog&>(dog);
	d.fix_position();
	d.set_direction();
}

void PlayerBlock(GameObject& Player, GameObject& Block)
{
}

void BirdPath(GameObject& bird, GameObject& Path) 
{
	Bird& b = static_cast<Bird&>(bird);
	b.set_y_position(9);
}



void FireCarrotsBird(GameObject& FireCarrots, GameObject& Bird)
{

}

void MouseFireCarrots(GameObject& mouse, GameObject& FireCarrots)
{
	
	Mouse& m = static_cast<Mouse&>(mouse);
	m.setTimes();
	m.setScale();
	


}
void DogFireCarrots(GameObject& dog, GameObject& FireCarrots)
{
	
}

void FireCarrotsMouse(GameObject& FireCarrots, GameObject& Mouse)
{
	MouseFireCarrots(Mouse, FireCarrots);
}
void FireCarrotsDog(GameObject& FireCarrots, GameObject& Dog)
{


}
void MousePath(GameObject& mouse, GameObject& Path)
{
	Mouse& m = static_cast<Mouse&>(mouse);
	m.set_y_position(9);
}
void DogPath(GameObject& dog, GameObject& Path)
{
	Dog& d = static_cast<Dog&>(dog);
	d.set_y_position(9);
}


void playerPath(GameObject& player, GameObject& Path) 
{
	Player& b = static_cast<Player&>(player);
	b.set_y_position(9);
}
void playerAddLifeGift(GameObject& player, GameObject& AddLifeGift)
{
	Singleton::show().get_sound(2).play();
	Player& p = static_cast<Player&>(player);
	p.addLife();
}
void playerAddScoreGift(GameObject& player, GameObject& AddScoreGift)
{
	Singleton::show().get_sound(2).play();
	Player& p = static_cast<Player&>(player);
	p.increaseScore();
}
void playerAddCarrotsGift(GameObject& player, GameObject& AddCarrotsGift)
{

	Singleton::show().get_sound(11).play();
	Player& p = static_cast<Player&>(player);
	p.addGiftCarrots();
}