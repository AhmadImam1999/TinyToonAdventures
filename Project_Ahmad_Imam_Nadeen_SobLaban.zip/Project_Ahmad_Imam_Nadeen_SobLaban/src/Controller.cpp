#pragma once

#include "Controller.h"


//--------------------Constructor for Controller---------------------
Controller::Controller() : m_pic(ZERO), m_jumping(false), m_direction(Up)
{
	m_FCarrotsSound = Singleton::show().get_sound(ZERO);
}

//---------Main run function for to start the game---------
void Controller::run(float width, float height, int choice)
{
	bool moving = false, moveEnemy = false;
	float clock_sample = ZERO, gameClock = ZERO;
	int lastLevel = 5;
	sf::View view;
	sf::Event event;
	sf::Clock clock;
	setGame();
	for (int level_num = 1; level_num <= lastLevel; level_num++)
	{
		sf::RenderWindow m_window(sf::VideoMode(width, height), "Tiny Toon Adventures");
		background[level_num - ONE].setSize(sf::Vector2f(m_window.getSize().x * 10, m_window.getSize().y));
		sf::Vector2f screen_focus1((float)m_window.getSize().x / TWO, (float)m_window.getSize().y / TWO);
		m_window.setFramerateLimit(TWENTY);

		view.reset(sf::FloatRect((float)ZERO, (float)ZERO, (float)m_window.getSize().x, (float)m_window.getSize().y));
		view.setViewport(sf::FloatRect(0.0f, 0.f, 1.0f, 1.0f));

		Board level(level_num); //create level.
		setLevel(choice, level_num, level);


		while (m_window.isOpen() && player.getLives() != ZERO)
		{

			gameClock = game_clock.getElapsedTime().asSeconds();
			gameClock = level.get_levelTime() - gameClock;

			//player.setPlayer(sf::Vector2i(ZERO,ZERO), TWO);

			if (gameClock < ONE)
			{
				player.decreaseLife();
				player.resetPosition();
				gameClock = level.get_levelTime();
				game_clock.restart();
			}

			while (m_window.pollEvent(event))
			{
				if (event.key.code == sf::Keyboard::Escape)
				{
					m_window.close();
					return;
				}
				if (event.type == sf::Event::KeyReleased)
				{
					player.setJump(false);
				}
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space) && sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
			{
				m_direction = Right;
				jump(m_window, background[level_num - ONE], screen_focus1, view, POINTTHIRYFIVE, event, level, clock_sample, gameClock, level_num);
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space) && sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
			{
				m_direction = Left;
				jump(m_window, background[level_num - ONE], screen_focus1, view, NEGPOINTTHIRYFIVE, event, level, clock_sample, gameClock, level_num);
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
				jump(m_window, background[level_num - ONE], screen_focus1, view, ZERO, event, level, clock_sample, gameClock, level_num);

			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
			{
				m_direction = Left;
				moving = true;
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
			{
				m_direction = Right;
				moving = true;
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
			{
				if (player.getClimbStatus())
				{
					m_direction = Up;
					moving = true;
				}
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
			{
				if ((!level.isOnPath(player) || level.isOnRope(player)))
				{
					player.setClimb(true);
					m_direction = Down;
					moving = true;
				}
			}


			if (sf::Keyboard::isKeyPressed(sf::Keyboard::X) && player.getCarrots() > 0 ||
				sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && sf::Keyboard::isKeyPressed(sf::Keyboard::X) && player.getCarrots() > 0 ||
				sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && sf::Keyboard::isKeyPressed(sf::Keyboard::X) && player.getCarrots() > 0)
			{

				m_FCarrotsSound.play();
				FireCarrots F(player);
				m_Fire_Carrots = true;
				F.set_pos(player);
				F.set_dirc(m_direction);
				player.lessCarrots();
				m_FCarrots.emplace_back(F);
			}

			if (moveEnemy)
			{
				level.moveEnemy(player.getPosition(), clock_sample);
				level.CheckForEnemyCollision(player, m_FCarrots);
			}

			if (moving)
			{
				moveEnemy = true;
				clock_sample = clock.getElapsedTime().asSeconds();	//update the counter.
				move(POINTTHIRYFIVE, POINTTHIRYFIVE, level, moving, m_direction, distance(clock_sample));


				moving = false;
			}
			m_lvlDone = player.getDoorPassStatus();
			if (m_lvlDone)
			{
				if (level_num == lastLevel)
				{
					setGameLevels(m_window, view, 9, 18);
					break;
				}
				player.resetCarrots();
				m_lvlDone = false;
				player.setDoorPassStatus(false);
				player.setDoorPassStatus(false);
				setGameLevels(m_window, view, 8, 19);
				break;
			}
			
			
			if (player.getLives() == ZERO)
			{
				setGameLevels(m_window, view, 10, 17);
				return;
			}
			isClimb(level, player);
			draw(m_window, background[level_num - ONE], screen_focus1, view, level, clock_sample, gameClock);
			clock.restart(); //restart the clock.	
			isFireCarrots(level, m_window, clock_sample);
			m_window.display();
		}
	}
}


//---------------------------------------draw function of all objects------------------------------------------------

void Controller::draw(sf::RenderWindow& window, sf::RectangleShape& rec, sf::Vector2f& screen_focus1, sf::View& view,
	Board& level, float clock_sample, float GameClock)
{
	window.clear();
	sf::Vector2f Tiny_pos = player.getPosition();

	Tiny_pos.x = Tiny_pos.x * SHAPE + TO_CENTER;
	Tiny_pos.y = Tiny_pos.y * SHAPE + TO_CENTER;

	if (Tiny_pos.x + 10> (window.getSize().x / TWO)) // set screen focus on player
		Tiny_pos.x = screen_focus1.x = Tiny_pos.x + 10;
	else
		Tiny_pos.x = screen_focus1.x = (float)window.getSize().x / TWO;


	view.setCenter(screen_focus1);
	window.setView(view);
	window.draw(rec);
	level.draw(window, clock_sample);
	level.drawEnemy(window, clock_sample);
	player.draw(window, GameClock);
}

void Controller::setGame()
{

	menuMusic = Singleton::show().get_sound(6);

	menuMusic.setLoop(true);
	menuMusic.setVolume(4);
	menuMusic.play();

	for (int i = ZERO; i < 5; i++)
	{
		
		background[i].setTexture(Singleton::show().get_pic(STARTPIC + i));
		background[i].setPosition(ZERO, ZERO);
		
	}
	background[5].setTexture(Singleton::show().get_pic(18)); //victory
	background[5].setPosition(ZERO, ZERO);
	background[6].setTexture(Singleton::show().get_pic(19)); //levelup
	background[6].setPosition(ZERO, ZERO);
	background[7].setTexture(Singleton::show().get_pic(17)); //gameover
	background[7].setPosition(ZERO, ZERO);
}




//-------------------------------function that utilizes the jump of the player-----------------------------------
void Controller::jump(sf::RenderWindow& window, sf::RectangleShape& rec, sf::Vector2f& screen_focus1, sf::View& view,
	float x, sf::Event& event, Board& level, float clock_sample, float gameClock, int level_num)
{
	Singleton::show().get_sound(7).play();
	player.setClimb(false);
	bool moving = true;
	m_jumping = true;
	player.setJump(true);
	m_velocityX = x;
	m_velocityY = MINUSTHIRTY;

	while (m_jumping)
	{
		while (window.pollEvent(event))
		{

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::X))
			{
				m_FCarrotsSound.play();
				FireCarrots F(player);
				m_Fire_Carrots = true;
				F.set_pos(player);
				F.set_dirc(m_direction);
				m_FCarrots.emplace_back(F);
				break;
			}
		}
		if (!player.getJumpStatus())
		{
			m_jumping = false;
			break;
		}
		if (level.isOnGround(player) && m_velocityY > ZERO)
		{
			player.set_y_position((int)player.getPosition().y + ONE);
			m_jumping = false;
			break;
		}

		if (m_y < GROUNDLEVEL) //If you are above ground
			m_velocityY += m_gravity;//Add gravity
		if (x == ZERO)
			m_direction = m_direction;
		if (x == POINTTHIRYFIVE)
			m_direction = Right;
		if (x == NEGPOINTTHIRYFIVE)
			m_direction = Left;

		m_x += m_velocityX;
		m_y += m_velocityY;

		move(m_velocityX, m_velocityY, level, moving, m_direction, ZERO);
		draw(window, background[level_num - ONE], screen_focus1, view, level, clock_sample, gameClock);

		if (!m_FCarrots.empty())
		{
			FireCarrotsMode(level);
			for (int i = ZERO; i < m_FCarrots.size(); i++)
				m_FCarrots[i].draw(window, clock_sample);
		}

		window.display();
		if (player.getPosition().y > EIGHTPOINTFIVE && m_velocityY > ZERO)
		{
			player.set_y_position(9); //change to floorHeight member
			player.setJump(false);
			m_jumping = false;
		}
	}
	player.setJump(false);
}

void Controller::FireCarrotsMode(Board& level)
{
	level.checkFireCarrotsColission(m_FCarrots);
	for (int i = ZERO; i < m_FCarrots.size(); i++)
	{
		m_FCarrots[i].move(ZERO, ZERO, ZERO);
		m_FCarrots[i].set_distance();

		if (m_FCarrots[i].get_distance() == ZERO)
		{
			m_FCarrots.erase(m_FCarrots.begin() + i);
		}
	}
}
void Controller::move(float distance_x, float distance_y, Board& level, bool move, float dirc, float clock_sample)
{

	if (move)
	{
		level.moveEnemy(player.getPosition(), clock_sample);
		level.CheckForCollision(player);
		sf::Vector2f player_prev = player.getPosition(); // the current location of object.

		player.setPrevPos(player_prev);
		if (m_jumping)
		{
			player.move(distance_x, distance_y, dirc);
		}
		else if (m_direction == Left)
			player.move(-distance_x, distance_y, m_direction);	//move the player.
		else
			player.move(distance_x, distance_y, m_direction);	//move the player.

	}
}

float Controller::distance(float clock_sample) const
{
	float distance = clock_sample * HUNDREDFIFTY; // player distance by clock;
	return distance;
}


// sets the game level
void Controller::setLevel(int& playerChoose, int& levelNum, Board& level)
{
	sf::Vector2i player_pos = level.get_player();

	int Carrots = level.get_Carrots();

	player.setStatus(Carrots);
	player.setPlayer(player_pos, playerChoose);
}

void Controller::setGameLevels(sf::RenderWindow& window, sf::View& v, int x, int y)
{
	//menuMusic.stop();
	Singleton::show().get_sound(x).play();
	sf::Vector2f screen_focus1((float)window.getSize().x / TWO, (float)window.getSize().y / TWO);
	v.reset(sf::FloatRect((float)ZERO, (float)ZERO, (float)window.getSize().x, (float)window.getSize().y));
	v.setViewport(sf::FloatRect(0.0f, 0.f, 1.0f, 1.0f));
	v.setCenter(screen_focus1);
	window.setView(v);
	sf::Sprite geT;
	geT.setTexture(*Singleton::show().get_pic(y));
	geT.setTextureRect(sf::IntRect(ZERO, ZERO, LEVELWIDTH, LEVELHEIGHT));
	window.draw(geT); //show the trophy.
	window.display();
	Sleep(SLEEPSCREEN);
	window.close();
}


void Controller::isFireCarrots(Board& level, sf::RenderWindow& window, float& clockSample)
{
	if (!m_FCarrots.empty())
	{
		FireCarrotsMode(level);
		for (auto& item2 : m_FCarrots)
			item2.draw(window, clockSample);
	}
}

void Controller::isClimb(Board& level, Player& player) const
{
	if (!level.isFloating(player))
	{
		level.handleFloating(player);
	}
	if (level.isClimbing(player) && player.getClimbStatus())
	{
		player.setClimb(false);
	}
}

