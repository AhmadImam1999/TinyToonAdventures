#pragma once

#include "Gift.h"

Gift::Gift()
{

}