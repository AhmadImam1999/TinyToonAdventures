#pragma once
#include <Controller.h>
#include <Block.h>
#include <Carrots.h>
#include <Floor.h>
#include <Door.h>
#include "Board.h"
#include "Collision.h"
#include "BabsBunny.h"
#include "Rope.h"
#include "AddCarrotsGift.h"
#include "AddLifeGift.h"
#include "AddScoreGift.h"
#include "Dog.h"

// build the level by the level number.
Board::Board(int level) : colided(false), FireCarrotsColided(false), m_Carrots(ZERO), m_fallSpeed(ZERO)
{
	m_level = level;
	ifstream file; //to read from file.
	char num = (char)(m_level)+'0';
	string end = ".txt";
	string file_name = "";
	file_name += num;
	file_name += end;
	file.open(file_name); //the name of the file.
	copy_to_file_vector(file); //copy to the file vector.
	make_m_board(); //do assign to the m_board.
	define_m_board(m_file_vector); //copy to the static vector.
}

// copy the level string from file to the string vector.
void Board::copy_to_file_vector(ifstream& file)
{
	string line;

	file >> m_length >> m_width >> m_levelTime >> m_Carrots;

	getline(file, line); //eat enter;

	for (int index = ZERO; index < m_length; index++) // build the map
	{
		getline(file, line);
		m_file_vector.emplace_back(line); // reads the file into vector line by line
	}
}

void Board::define_m_board(vector<string>m_file_vector)
{
	char icon;
	sf::Vector2i location;

	for (int y = ZERO; y < m_length; y++)
	{
		for (int x = ZERO; x < m_width; x++)
		{
			location.x = x;
			location.y = y;

			icon = m_file_vector[y][x];

			switch (icon)
			{
				//-------------------------------\\static object//-----------------------------------------
			case Floor_object:m_board[y][x] = make_unique <Floor>(location, Floor_object); //Floor
				break;

			case Block_object:m_board[y][x] = make_unique <Block>(location, Block_object); //Block
				break;

			case Carrots_object:m_board[y][x] = make_unique <Carrots>(location, Carrots_object);//Carrots
				break;
			case Door_object:m_board[y][x] = make_unique <Door>(location, Door_object); //Door
				break;
			case Rope_object:m_board[y][x] = make_unique <Rope>(location, Rope_object); //Rope
				break;
			case BabsBunny_object:m_board[y][x] = make_unique <BabsBunny>(location, BabsBunny_object); //SpecialBlock
				break;
			case AddLifeGift_object:m_board[y][x] = make_unique <AddLifeGift>(location, AddLifeGift_object); //AddLifeGift
				break;
			case AddScoreGift_object:m_board[y][x] = make_unique <AddScoreGift>(location, AddScoreGift_object); //AddScoreGift
				break;
			case AddCarrotsGift_object:m_board[y][x] = make_unique <AddCarrotsGift>(location, AddCarrotsGift_object); //AddCarrotsGift
				break;
				//-------------------------------Active object//-----------------------------------------
			case player_object:
				playerLoc = location;
				break;
			case bird_object:
				m_Enemy.emplace_back(make_unique <Bird>(location, bird_object)); //Bird
				break;
			case Mouse_object:
				m_Enemy.emplace_back(make_unique <Mouse>(location, Mouse_object)); //Mouse
				break;
			case Dog_object:
				m_Enemy.emplace_back(make_unique <Dog>(location, Dog_object)); //Mouse
				break;
			}
		}
	}
}


// build the m_board vector and define him to be nullptr in every cell.
void Board::make_m_board()
{
	m_board.resize(m_length);

	for (auto& m : m_board)
		m.resize(m_width);

	for (int i = ZERO; i < m_length; i++)
	{
		for (int j = ZERO; j < m_width; j++)
			m_board[i][j] = nullptr;
	}
}

//draw the static objects on the board.
// draws all objects on game board
void Board::draw(sf::RenderWindow& win, float clock_sample)
{
	for (int y = ZERO; y < m_length; y++)
	{
		for (int x = ZERO; x < m_width; x++)
		{
			if (m_board[y][x])//if not null
				if (typeid(m_board[y][x]) != typeid(Player))
					m_board[y][x]->draw(win, clock_sample);
		}
	}
}

void Board::drawEnemy(sf::RenderWindow& win, float clock_sample) const
{
	for (int i = ZERO; i < m_Enemy.size(); i++)
		m_Enemy[i]->draw(win, clock_sample);
}

// checks for collision between player and other objects
void Board::CheckForCollision(Player& p)
{
	for (int i = ZERO; i < m_length; i++)
	{
		for (int j = ZERO; j < m_width; j++)
		{
			if (m_board[i][j] != nullptr)
			{
				if (ObjectsCollided(p, *m_board[i][j]))
				{
					Collision::instance().processCollision(p, *m_board[i][j]);
					if (typeid(*m_board[i][j]) == typeid(Carrots) || typeid(*m_board[i][j]) == typeid(AddScoreGift)
						|| typeid(*m_board[i][j]) == typeid(AddLifeGift) || typeid(*m_board[i][j]) == typeid(AddCarrotsGift))
						m_board[i][j] = nullptr;

				}

			}
		}
	}

	if (!colided)
	{
		for (int z = 0; z < m_Enemy.size(); z++)
		{
			if (ObjectsCollided(p, *m_Enemy[z]))
			{
				if (p.getJumpStatus() && !(typeid(*m_Enemy[z]) == typeid(Dog)))
				{
					m_Enemy.erase(m_Enemy.begin() + z);
				}
				else
				{
					Collision::instance().processCollision(p, *m_Enemy[z]);
				}
			}
		}
	}
	else
		colided = false;
}
void Board::CheckForEnemyCollision(Player& p, vector<FireCarrots>& m_FCarrots)
{
	for (int i = 0; i < m_length; i++)
	{
		for (int j = 0; j < m_width; j++)
		{
			for (int z = 0; z < m_Enemy.size(); z++)
			{
				if (m_board[i][j] != nullptr)
				{
					if (ObjectsCollided(*m_Enemy[z], *m_board[i][j]))
					{
						Collision::instance().processCollision(*m_Enemy[z], *m_board[i][j]);
					}
				}
			}
		}
	}

	for (int i = ZERO; i < m_FCarrots.size(); i++)
	{
		for (int z = ZERO; z < m_Enemy.size(); z++)
		{
			if (ObjectsCollided(m_FCarrots[i], *m_Enemy[z]))
			{

				m_Enemy.erase(m_Enemy.begin() + z);

				m_FCarrots.erase(m_FCarrots.begin() + i);
				break;
			}
		}
		if (m_FCarrots.empty() || m_Enemy.empty())
			break;
	}
}

void Board::checkFireCarrotsColission(vector<FireCarrots>& m_FCarrots)
{

	for (int i = ZERO; i < m_FCarrots.size(); i++)
	{
		for (int z = ZERO; z < m_Enemy.size(); z++)
		{
			if (ObjectsCollided(m_FCarrots[i], *m_Enemy[z]))
			{
				
					m_Enemy.erase(m_Enemy.begin() + z);
					m_Enemy.erase(m_Enemy.begin() + i);
					break;
			
			}
		}
		if (m_FCarrots.empty() || m_Enemy.empty())
			break;
	}

	for (int x = ZERO; x < m_FCarrots.size(); x++)
	{
		FireCarrotsColided = false;
		for (int i = ZERO; i < m_length; i++)
		{
			for (int j = ZERO; j < m_width; j++)
			{
				if (m_board[i][j] != nullptr)
				{
					if (ObjectsCollided(m_FCarrots[x], *m_board[i][j]))
					{
						if (typeid(*m_board[i][j]) == typeid(Block) || typeid(*m_board[i][j]) == typeid(Door) ||
							 typeid(*m_board[i][j]) == typeid(Rope)
							|| typeid(*m_board[i][j]) == typeid(AddCarrotsGift) || typeid(*m_board[i][j]) == typeid(AddLifeGift)
							|| typeid(*m_board[i][j]) == typeid(AddScoreGift))
						{
							m_FCarrots.erase(m_FCarrots.begin() + x);
							FireCarrotsColided = true;
							break;
						}
					}
				}
			}
			if (m_FCarrots.empty() || FireCarrotsColided)
				break;
		}
		if (m_FCarrots.empty())
			break;
	}

}
// the collision identification function
bool Board::ObjectsCollided(GameObject& obj1, GameObject& obj2) const
{
	return obj1.get_sprite().getGlobalBounds().intersects(obj2.get_sprite().getGlobalBounds());
}
// floating check
bool Board::isFloating(Player& p) const
{
	sf::Vector2f pos = p.getPosition();
	pos.x = (pos.x * SHAPE + TO_CENTER) / SHAPE;
	pos.y = (pos.y * SHAPE + TO_CENTER) / SHAPE;


	if (m_board[(int)(pos.y) + ONE][(int)pos.x] == nullptr)
		return false;
	if (typeid(*m_board[(int)(pos.y) + ONE][(int)pos.x]) == typeid(Floor) ||
		typeid(*m_board[(int)(pos.y) + ONE][(int)pos.x]) == typeid(Block) ||
		typeid(*m_board[(int)(pos.y) + ONE][(int)pos.x]) == typeid(Rope) )
		return true;
}
// floor ckeck
bool Board::isOnPath(Player& p) const
{
	sf::Vector2f pos = p.getPosition();
	pos.x = (pos.x * SHAPE + TO_CENTER) / SHAPE;
	pos.y = (pos.y * SHAPE + TO_CENTER) / SHAPE;

	if (m_board[(int)(pos.y) + ONE][(int)pos.x] == nullptr)
		return false;
	if (typeid(*m_board[(int)(pos.y) + ONE][(int)pos.x]) == typeid(	Floor))
		return true;
	else
		return false;
}
// ground level check
bool Board::isOnGround(Player& p) const
{
	sf::Vector2f pos = p.getPosition();
	pos.x = (pos.x * SHAPE + TO_CENTER) / SHAPE;
	pos.y = (pos.y * SHAPE + TO_CENTER) / SHAPE;

	if (m_board[(int)(pos.y) + ONE][(int)pos.x] == nullptr)
		return false;
	if (typeid(*m_board[(int)(pos.y) + ONE][(int)pos.x]) == typeid(Floor) ||
		typeid(*m_board[(int)(pos.y) + ONE][(int)pos.x]) == typeid(Block))
		return true;
	else
		return false;
}

bool Board::isOnRope(Player& p) const
{
	sf::Vector2f pos = p.getPosition();
	pos.x = (pos.x * SHAPE) / SHAPE;
	pos.y = (pos.y * SHAPE + SHAPE) / SHAPE;

	if (m_board[(int)(pos.y) + ONE][(int)pos.x] == nullptr)
		return false;
	if (typeid(*m_board[(int)(pos.y) + ONE][(int)pos.x]) == typeid(Rope))
		return true;
	else
		return false;
}

// climbing status
bool Board::isClimbing(Player& p) const
{
	sf::Vector2f pos = p.getPosition();

	pos.y = (pos.y * SHAPE + SHAPE) / SHAPE;

	if (m_board[(int)(pos.y) + ONE][(int)pos.x] == nullptr)
		return false;
	if (typeid(*m_board[(int)(pos.y) + ONE][(int)pos.x]) == typeid(Rope))
		return true;
	else
		return false;
}
// floating handeling
void Board::handleFloating(Player& p)
{
	m_fallSpeed++;
	if (m_fallSpeed == TWO)
	{
		CheckForCollision(p);
		sf::Vector2f pos = p.getPosition();
		float x = p.get_direction();
		if (pos.y > 8)
			p.set_y_position(9);
		else
		{
			pos.y += ONE;
			if (x == ONE)
				pos.x -= POINTFIVE;
			else
				pos.x += POINTFIVE;
			p.set_location(pos);
		}
		m_fallSpeed = ZERO;
	}
}

// geting static objects on board
const StaticObject* Board::get_object(sf::Vector2f place) const
{
	sf::Vector2i object;
	object.x = (int)place.x;
	object.y = (int)place.y;
	if (object.y >= m_length || object.x >= m_width)
		return nullptr;

	return m_board[object.y][object.x].get();
}

const sf::Vector2i Board::get_player() const
{
	return playerLoc;
}

// geting level time 
const int Board::get_time() const
{
	return m_time;
}

//return the width
const int Board::get_width() const
{
	return m_width;
}


//return the lenth
const int Board::get_length() const
{
	return m_length;
}


//return the lenth
const int Board::get_levelTime() const
{
	return m_levelTime;
}
//return the lenth
const int Board::get_Carrots() const
{
	return m_Carrots;
}

// setting level time
void Board::set_time(int elapsed)
{
	m_time = elapsed;
}

// will release a unique ptr of an object on board.
void Board::set_object_null(sf::Vector2f place)
{
	sf::Vector2i object;
	object.x = place.x;
	object.y = place.y;

	m_board[object.y][object.x] = nullptr;
}

void Board::moveEnemy(sf::Vector2f playerLoc, float clock_sample) const
{
	for (int i = ZERO; i < m_Enemy.size(); i++)
		m_Enemy[i]->movement(playerLoc.x, clock_sample, playerLoc.y);
}