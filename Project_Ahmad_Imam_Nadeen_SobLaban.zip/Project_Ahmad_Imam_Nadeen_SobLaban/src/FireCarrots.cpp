#pragma once

#include "FireCarrots.h"

//c-tor
FireCarrots::FireCarrots(Player& p)
{
	set_pos(p);
	setFireCarrots();
}


void FireCarrots::move(float x, float y, float dirc)
{
	if (m_dirc == 2)
		m_FireCarrots_pos.x += m_dirc * 11;
	else
		m_FireCarrots_pos.x -= m_dirc * 15;

	m_FireCarrotsSpr.setPosition(m_FireCarrots_pos);
	m_FireCarrotsSpr_op.setPosition(m_FireCarrots_pos);
}

void FireCarrots::draw(sf::RenderWindow& window, float clock_sample)
{
	if (m_dirc == 2)//right
		window.draw(m_FireCarrotsSpr);
	else//left
		window.draw(m_FireCarrotsSpr_op);
}


void FireCarrots::setFireCarrots()
{
	m_FireCarrotsSpr.setTexture(*Singleton::show().get_pic(12));
	m_FireCarrotsSpr.setScale(0.6, 0.6);
	m_FireCarrotsSpr.setPosition(m_FireCarrots_pos);
	m_FireCarrotsSpr_op.setTexture(*Singleton::show().get_pic(25));
	m_FireCarrotsSpr_op.setScale(sf::Vector2f(0.6, 0.6));
	m_FireCarrotsSpr_op.setPosition(m_FireCarrots_pos);
}

void FireCarrots::set_y_position(float y)
{
}

sf::Sprite FireCarrots::get_sprite()
{
	if (m_dirc == 2)//right
		return(m_FireCarrotsSpr);
	else//left
		return(m_FireCarrotsSpr_op);
}

void FireCarrots::set_pos(Player& p)
{
	sf::Vector2f pos = p.getPosition();
	m_FireCarrots_pos.x = pos.x * SHAPE;
	m_FireCarrots_pos.y = pos.y * SHAPE;
	m_FireCarrots_pos.x += (TO_CENTER + 0.3);
	m_FireCarrots_pos.y += TO_CENTER / 3;
}
