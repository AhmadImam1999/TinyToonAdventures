#pragma once

#include "GameObject.h"

GameObject::GameObject()
{

}
