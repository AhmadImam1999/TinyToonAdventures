#pragma once

#include "ActiveObject.h"

//ActiveObject constructor
ActiveObject::ActiveObject() : m_speed(0)
{
}