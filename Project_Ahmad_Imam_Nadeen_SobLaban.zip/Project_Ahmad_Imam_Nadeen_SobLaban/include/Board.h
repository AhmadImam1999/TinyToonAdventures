#pragma once

#include <SFML\Graphics.hpp>
#include <Vector>
#include <string>
#include <fstream> 
#include <iostream>
#include <cstdlib>
#include <conio.h>
#include <cmath>
#include <memory>
#include "Dog.h"
#include "StaticObject.h"
#include "Player.h"
#include "BabsBunny.h"
#include "Enemy.h"
#include "FireCarrots.h"
#include "Rope.h"
#include "AddCarrotsGift.h"
#include "AddScoreGift.h"
#include "AddLifeGift.h"

using std::vector;
using std::ifstream;
using std::string;
using std::make_unique;

constexpr double POINTFIVE = 0.5;

enum types {
	Floor_object = '#', Block_object = 'B', Carrots_object = 'C', Door_object = 'D', BabsBunny_object = '@', Dog_object = 'd',
	bird_object = 'b', Mouse_object = 'M', player_object = 'P', Rope_object = 'I', AddScoreGift_object = 'S', AddCarrotsGift_object = 'c', AddLifeGift_object = 'L'
};

// The Board class represents all objects that are drawn on the screen
class Board
{

public:

	//----Constructor for Board------
	Board() = default;
	Board(int level);


	void draw(sf::RenderWindow& win, float clock_sample); // draws all objects on game board
	void set_object_null(sf::Vector2f place);
	void set_time(int elapsed); // sets game time
	void CheckForCollision(Player& p); // checks for collisions between objects
	void CheckForEnemyCollision(Player& p, vector<FireCarrots>& m_FireCarrots); // checks for collision betwen monsters and objects
	void handleFloating(Player& p); // handles player floating
	void moveEnemy(sf::Vector2f playerLoc, float clock_sample) const; // runs the move functions of Enemy
	void drawEnemy(sf::RenderWindow& win, float clock_sample) const; // draws Enemy
	void checkFireCarrotsColission(vector<FireCarrots>& m_knifes); // checks collisions between weapons and other game objects

	const int get_width() const; // get level width
	const int get_time() const; // get level time 
	const int get_length() const; // get level lenght 
	const int get_Carrots() const; // get level diamonds
	const int get_levelTime() const; // get level time
	bool isClimbing(Player& p) const; // Player climb check
	bool ObjectsCollided(GameObject& obj1, GameObject& obj2) const;
	bool isFloating(Player& p) const; // Player floating check
	bool isOnPath(Player& p) const; // Player floor check
	bool isOnGround(Player& p) const; // Player ground check
	bool isOnRope(Player& p) const; // Player ladder check
	const StaticObject* get_object(sf::Vector2f place) const; // returns a pointer to static objets for access purpuses

	const sf::Vector2i get_player() const; // gets player location on board


private:
	int m_fallSpeed; // player fall speed
	int m_time; // curent level time
	int m_level; // number of current level.
	int m_width; // level width
	int m_length; // level lenght
	int m_Carrots; // number of Currotss in current level
	int m_levelTime; // level timer

	vector <std::unique_ptr<Enemy>> m_Enemy; //static objects vector.
	vector <string> m_file_vector; //vector of string.
	vector <vector <std::unique_ptr<StaticObject>>> m_board; //static objects vector.

	bool FireCarrotsColided;
	bool colided;

	void copy_to_file_vector(ifstream& file); // loads current file to memory
	void define_m_board(vector <string> m_file_vector); // inserts the level file into game memory
	void make_m_board(); // creates the game board

	sf::Vector2i playerLoc; // player location on board
};

