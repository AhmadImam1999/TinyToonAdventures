#pragma once
#include "Enemy.h"
#include <ostream>


class Dog : public Enemy
{

public:

	//----Constructor for Mouse object------
	Dog(sf::Vector2i location, char icon);

	void draw(sf::RenderWindow& window, float clock_sample)override; // draw func
	void update_time_counter(float add); // func to update time counter
	void move(float x, float y, float dirc) override {}; // empty definition used for polymorphism
	void movement(float x, float y, float dirc) override; // empty definition used for polymorphism
	void set_y_position(float y) override {}; // empty definition used for polymorphism
	void setLocation(float newState) { m_location.x *= newState; };
	void set_location(sf::Vector2f location);
	void set_direction();
	void setScale();
	void setTimes() { m_times += 1; };
	void fix_position();

	directions_t get_direction() const; // gets directions from enum
	const sf::Vector2f get_location() const;
	const sf::Sprite get_sprite() const { return m_pic; };
	const int getTimes() const { return m_times; };

private:

	float m_x;
	float m_time_counter; // lives counter
	int m_times; // lives member
	float m_scale = 0.7;
};
