#pragma once
#include "ActiveObject.h"

//============================================================================

class Utilities
{
public:

	// c'tor
	Utilities();
	// d'tor
	~Utilities();
};


// func to check from witch side the intersection accured
directions_t intersectionType(const sf::FloatRect& first, const sf::FloatRect& second, const sf::FloatRect& intersectionRect);
