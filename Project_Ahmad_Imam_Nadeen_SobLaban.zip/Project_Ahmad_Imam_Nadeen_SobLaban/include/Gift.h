#pragma once

#include "StaticObject.h"

class Gift : public StaticObject
{

public:

	//----Constructor for present base------
	Gift();
	~Gift() = default;

private:

};