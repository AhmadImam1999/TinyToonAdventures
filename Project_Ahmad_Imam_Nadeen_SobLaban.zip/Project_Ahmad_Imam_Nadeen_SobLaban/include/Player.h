#pragma once

#include <SFML/Graphics.hpp>
#include <iostream>
#include <cstdlib> 
#include <stdlib.h>
#include <string>
#include <vector>
#include "StatusBar.h"
#include "singleton.h"
#include "ActiveObject.h"

class Player : public ActiveObject
{

public:

	//----Constructor for player object------
	Player();
	~Player() = default;


	void move(float x, float y, float dirc) override; // player movement
	void draw(sf::RenderWindow& window, float gameClock); //player draw
	void fix_position(); // fixes player position
	void increaseScore() { m_status.set_score(10); }; // increases player score
	void setStatus( int& Carrots); // gets player status
	void addCarrots() { m_status.set_Carrots(1); }; // adds Carrotss to player
	void addGiftCarrots() { m_status.set_Carrots(3); };
	void lessCarrots() { m_status.set_Carrots(-1); }; // adds Carrotss to player
	void decreaseLife(); // decreases player lives
	void resetCarrots();
	void addLife() { m_status.set_lives(1); }; // adds lives to player
	void setClimb(bool x) { m_climb = x; }; // set player to climbing mode
	void addScore() { m_status.set_score(10); }; // adds score to player
	void addTime() { m_status.set_time(); }; // adds time to player
	void resetPosition() { set_location(original_pos); }; // player reset position
	bool getClimbStatus() const { return m_climb; }; // gets climb status
	void set_location(sf::Vector2f newp); // sets player location
	void set_y_position(float y)override; // player y position
	void setLocation(float newState) {}; // sets player location
	void setPlayer(sf::Vector2i pos, int x); // sets player position
	void setPrevPos(sf::Vector2f& prev) { prev_pos = prev; }; // player set position
	void setJump(bool x) { m_jump = x; }; // set player to jump mode
	void setDoorPassStatus(bool status) { m_passedInDoor = status; }; // sets key gate pass status
	bool getJumpStatus() const { return m_jump; }; // gets jump status
	bool getDoorPassStatus() const { return m_passedInDoor; }; // gets key gate pass status
	int getCarrots() { return m_status.get_Carrots(); }; // gets player Carrots
	const int getLives() const; // get player lives
	const int getCarrotsGoal() const { return m_status.get_Carrots_goal(); }; // gets diamonds goal number
	const sf::Vector2f getPosition() const { return player_pos; } // gets player position
	const sf::Vector2f get_location() const; // gets player location
	sf::Sprite get_sprite()override { return playerSpr; }; // gets player picture
	directions_t get_direction() const; // gets directions enum
protected:

	sf::RectangleShape background; // back ground
	sf::View viewStatus; // view 
	sf::Vector2i source; // source member
	sf::Vector2f player_pos; // position member
	sf::Vector2f prev_pos; // prev position member
	sf::Vector2f original_pos; // original position member
	sf::Sprite playerSpr; // player picture
	StatusBar m_status; // status bar member
	int m_pic; // picture
	int m_x; // x location
	int m_lives; // lives value
	int m_score; // score value
	float m_Xdistance; // floating on x 
	float m_Ydistance; // floating on y
	bool m_jump; // jump status
	bool m_passedInDoor = false; // key gate pass status
	bool m_climb; // climb statusz
};