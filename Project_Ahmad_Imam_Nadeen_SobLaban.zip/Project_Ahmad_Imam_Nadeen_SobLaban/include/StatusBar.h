#pragma once

#include <SFML/Graphics.hpp>

#include <string>
#include <ostream>
#include <sstream>

#include "singleton.h"

class StatusBar
{
public:

	//-------------Constructor for StatusBar--------------
	StatusBar(int lives, int score, int Carrots);
	const int get_lives() const;
	const int get_score() const;
	const int get_Carrots_goal() const;
	int get_Carrots() ;

	void set_lives(int lives);
	void set_score(int score);	
	void set_time() {m_time_bonus += 1;};
	void set_Carrots(int diamond);
	void set_goals( int &Carrots);
	void resetResources() ;
	void setGameClock(int elapsedTime, sf::RenderWindow& window);
	void draw(sf::RenderWindow& window) ;
	~StatusBar();

private:

	int m_score, m_lives, m_Carrots, m_minutes, m_CarrotsGoal, m_time_bonus;
	sf::Font m_font;
	std::ostringstream s_lives, s_score,  s_Carrots;
	sf::Text lives, score,  Carrots, m_clockNum;
};

