#pragma once

#include <SFML\Graphics.hpp>
#include <SFML\Audio.hpp>
#include <SFML\Audio.hpp>
#include <iostream>
#include <typeinfo>
#include <typeindex>
#include "GameObject.h"
#include "Carrots.h"
#include "Player.h"
#include "Floor.h"
#include "Block.h"
#include"BabsBunny.h"
#include "Door.h"
#include "Mouse.h"
#include "Bird.h"
#include "FireCarrots.h"
#include "Board.h"
#include "Rope.h"
#include "AddScoreGift.h"
#include "AddCarrotsGift.h"
#include "AddLifeGift.h"
#include "Dog.h"


using HitFunctionPtr = void (*)(GameObject&, GameObject&); // pointer to functions
using typesPair = std::pair<std::type_index, std::type_index>; // pair of objects
using HitMap = std::map<typesPair, HitFunctionPtr>; // The functions map

// The Collision class represents the map of collision functions (multimethods)
class Collision
{
public:

	static Collision& instance() ; // instantiation of collision map object
	void processCollision(GameObject& object1, GameObject& object2) ; // deal with collision function
    HitMap initializeCollisionMap() ; // initialization of collision map
	HitFunctionPtr lookup(const std::type_index& class1, const std::type_index& class2); // function that searches for the pointer to the specific collision function in the map
	~Collision() = default;

private:
	Board m_items;
	Collision() ; // constructor
	Collision(const Collision&) = delete;
	HitMap m_ObjectsMap; // map definition
	Collision& operator=(const Collision&) = delete;
};

// Global Collision Functions
void playerCarrots(GameObject& player, GameObject& Carrots) ; 
void playerRope(GameObject& player, GameObject& Rope);
void playerDoor(GameObject& player, GameObject& Door) ; 
void playerBabsBunny(GameObject& player, GameObject& BabsBunny) ; 
void playerMouse(GameObject& player, GameObject& Enemy) ; //
void playerBird(GameObject& player, GameObject& Enemy) ; 
void BirdPlayer(GameObject& Enemy, GameObject& player) ; 
void MousePlayer(GameObject& Enemy, GameObject& player) ;//
void EnemyItem(GameObject& Enemy, GameObject& player) ;
void MouseBlock(GameObject& Mouse, GameObject& Block) ;// 
void PlayerBlock(GameObject& Player, GameObject& Block);
void BirdBlock(GameObject& Bird, GameObject& Block);
void BirdBabsBunny(GameObject& Bird, GameObject& BabsBunny); 
void BirdFireCarrots(GameObject& Bird, GameObject& FireCarrots) ; 
void FireCarrotsBird(GameObject& FireCarrots, GameObject& Bird) ; 
void MouseFireCarrots(GameObject& Mouse, GameObject& FireCarrots); //
void FireCarrotsMouse(GameObject& FireCarrots, GameObject& Mouse);// 
void MousePath(GameObject& Mouse, GameObject& Path); //
void BirdPath(GameObject& Bird, GameObject& Path) ;
void playerPath(GameObject& player, GameObject& Path) ; 
/////
void playerAddScoreGift(GameObject& player, GameObject& AddScoreGift);
void playerAddLifeGift(GameObject& player, GameObject& AddLifeGift);
void playerAddCarrotsGift(GameObject& player, GameObject& floor);
////
void playerDog(GameObject& player, GameObject& Enemy);
void DogPlayer(GameObject& Enemy, GameObject& player);
void DogBlock(GameObject& Dog, GameObject& Block);
void DogFireCarrots(GameObject& Dog, GameObject& FireCarrots);
void FireCarrotsDog(GameObject& FireCarrots, GameObject& Dog);
void DogPath(GameObject& Dog, GameObject& Path);