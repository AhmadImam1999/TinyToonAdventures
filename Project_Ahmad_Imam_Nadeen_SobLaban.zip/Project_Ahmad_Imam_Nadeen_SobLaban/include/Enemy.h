#pragma once
#include "ActiveObject.h"

class Enemy : public ActiveObject
{

public:

	//----Constructors for Enemy base-----
	Enemy();
	~Enemy();
	void move(float x, float y, float dirc) override {}; // move Enmey 
	void set_y_position(float y) override {} ; // Enemy y position
	virtual void movement(float x, float y, float dirc) = 0; // Enemy movement

    sf::Sprite get_sprite() override { return m_pic; }; // Enemy picture

private:

};
