#pragma once

#include <SFML/Graphics.hpp>
#include <iostream>
#include <cstdlib> 
#include <stdlib.h>
#include <string>
#include <vector>
#include "Player.h"
#include"ActiveObject.h"
#include "Singleton.h"

class FireCarrots : public ActiveObject
{
public:

	//----Constructor for FireCarrots object------
	FireCarrots(Player& p);
	void move(float x, float y, float dirc)override; 
	void draw(sf::RenderWindow& window, float clock_sample)override; 
	void setFireCarrots(); 
	void set_pos(Player& p); 
	void set_dirc(float dirc) { m_dirc = dirc; }; 
	void set_y_position(float y)override;
	void set_distance() { m_distance--; }; 
	void setLocation(float newState) {};

	const int get_distance() const { return m_distance; }; 
	sf::Sprite get_sprite()override; 
	~FireCarrots() = default;

private:

	sf::Sprite m_FireCarrotsSpr; 
	sf::Sprite m_FireCarrotsSpr_op; 
	int m_distance = 40; 
	sf::Vector2f m_FireCarrots_pos; 
	sf::Texture m_FireCarrotsTex; 
	float m_dirc; 
};