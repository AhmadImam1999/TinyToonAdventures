#pragma once

#include "Gift.h"

class AddLifeGift : public Gift
{

public:

	//----Constructor for PresentScore object------
	AddLifeGift(sf::Vector2i location, char icon);
	void draw(sf::RenderWindow& win, float clock_sample); // draws the object on board
	void changPic()override {}; // changes the picture for animation
	void setLocation(float newState) {}; // sets objects location
	sf::Sprite get_sprite()override { return m_pic; }; // gets picture
	~AddLifeGift() = default;

private:


};